var moduleSearchIndex = [{"l":"console-clean","url":"index.html"}]
