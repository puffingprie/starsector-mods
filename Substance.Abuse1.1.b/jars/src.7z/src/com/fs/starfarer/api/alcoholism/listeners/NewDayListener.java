package com.fs.starfarer.api.alcoholism.listeners;

public interface NewDayListener {
    public void onNewDay();
}
