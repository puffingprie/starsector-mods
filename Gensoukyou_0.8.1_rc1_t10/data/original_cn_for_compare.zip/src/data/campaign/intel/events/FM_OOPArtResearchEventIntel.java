package data.campaign.intel.events;

import com.fs.starfarer.api.impl.campaign.intel.events.BaseEventIntel;

public class FM_OOPArtResearchEventIntel extends BaseEventIntel {
}
