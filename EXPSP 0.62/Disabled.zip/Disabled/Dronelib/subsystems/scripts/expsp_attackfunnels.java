package data.subsystems.scripts;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import data.scripts.ai.dl_BaseSubsystemDroneAI;
import data.scripts.impl.dl_DroneAPI;
import data.scripts.shipsystems.example.dl_FiverDroneSystem;
import data.scripts.subsystems.dl_BaseDroneSubsystem;
import data.scripts.util.dl_SpecLoadingUtils;
import data.shipsystems.scripts.ai.expsp_SubsystemDroneAI;

public class expsp_attackfunnels extends dl_BaseDroneSubsystem {
    public static final String SUBSYSTEM_ID = "expsp_drone_attackfunnel2"; //this should match the id in the csv

    public enum AttackFunnelOrders {
        DEFENCE,
        SHIELD,
        RECALL
    }
    private AttackFunnelOrders droneOrders = AttackFunnelOrders.RECALL;

    public expsp_attackfunnels() {
        super(dl_SpecLoadingUtils.droneSystemSpecHashMap.get("expsp_drone_attackfunnel2"), dl_SpecLoadingUtils.getSubsystemData(SUBSYSTEM_ID));
    }

    @Override
    public void apply(MutableShipStatsAPI stats, String id, SubsystemState state, float effectLevel) {

    }

    @Override
    public void unapply(MutableShipStatsAPI stats, String id) {

    }

    @Override
    public void nextDroneOrder() {
        droneOrders = getNextDroneOrder();
    }

    private AttackFunnelOrders getNextDroneOrder() {
        if (droneOrders.ordinal() == dl_FiverDroneSystem.FiverDroneOrders.values().length - 1) {
            return AttackFunnelOrders.values()[0];
        }
        return AttackFunnelOrders.values()[droneOrders.ordinal() + 1];
    }

    @Override
    public void maintainStatusMessage() {
        switch (droneOrders) {
          case SHIELD:
                maintainSystemStateStatus("SHIELD ARRAY FORMATION");
               break;
            case DEFENCE:
                maintainSystemStateStatus("DEFENCE FORMATION");
                break;
            case RECALL:
                if (deployedDrones.isEmpty()) {
                    maintainSystemStateStatus("DRONES RECALLED");
                } else {
                    maintainSystemStateStatus("RECALLING DRONES");
                }
                break;
        }
    }

    @Override
    public boolean isRecallMode() {
        return droneOrders == AttackFunnelOrders.RECALL;
    }

    @Override
    public void setDefaultDeployMode() {
        droneOrders = AttackFunnelOrders.DEFENCE;
    }

    @Override
    public void executePerOrders(float amount) {
        switch (droneOrders) {
            case DEFENCE:

                break;
          case SHIELD:

             break;
            case RECALL:

                break;
        }
    }

    public AttackFunnelOrders getDroneOrders() {
        return droneOrders;
    }

    @Override
    public dl_BaseSubsystemDroneAI getNewDroneAIInstance(dl_DroneAPI spawnedDrone) {
        return new expsp_SubsystemDroneAI(spawnedDrone, this);
    }

    @Override
    public void aiInit() {

    }

    @Override
    public void aiUpdate(float amount) {

    }

    @Override
    public String getFlavourString() {
        return "LAUNCHES DEFENSE DRONES";
    }

    @Override
    public String getStatusString() {
        return null;
    }
}
