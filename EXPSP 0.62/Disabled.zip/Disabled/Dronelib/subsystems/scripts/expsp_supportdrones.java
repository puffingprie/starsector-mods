package data.subsystems.scripts;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import data.scripts.ai.dl_BaseSubsystemDroneAI;
import data.scripts.impl.dl_DroneAPI;
import data.scripts.shipsystems.example.dl_FiverDroneSystem;
import data.scripts.subsystems.dl_BaseDroneSubsystem;
import data.scripts.util.dl_SpecLoadingUtils;
import data.shipsystems.scripts.ai.expsp_SubsystemDroneAIMK88;

public class expsp_supportdrones extends dl_BaseDroneSubsystem {
    public static final String SUBSYSTEM_ID = "expsp_drone_supportdrones"; //this should match the id in the csv

    public enum SupportDroneOrders {
        DEFENCE,
        SHIELD,
        RECALL
    }
    private SupportDroneOrders droneOrders = SupportDroneOrders.RECALL;

    public expsp_supportdrones() {
        super(dl_SpecLoadingUtils.droneSystemSpecHashMap.get("expsp_drone_supportdrones"), dl_SpecLoadingUtils.getSubsystemData(SUBSYSTEM_ID));
    }

    @Override
    public void apply(MutableShipStatsAPI stats, String id, SubsystemState state, float effectLevel) {

    }

    @Override
    public void unapply(MutableShipStatsAPI stats, String id) {

    }

    @Override
    public void nextDroneOrder() {
        droneOrders = getNextDroneOrder();
    }

    private SupportDroneOrders getNextDroneOrder() {
        if (droneOrders.ordinal() == dl_FiverDroneSystem.FiverDroneOrders.values().length - 1) {
            return SupportDroneOrders.values()[0];
        }
        return SupportDroneOrders.values()[droneOrders.ordinal() + 1];
    }

    @Override
    public void maintainStatusMessage() {
        switch (droneOrders) {
          case SHIELD:
                maintainSystemStateStatus("SHIELD ARRAY FORMATION");
               break;
            case DEFENCE:
                maintainSystemStateStatus("DEFENCE FORMATION");
                break;
            case RECALL:
                if (deployedDrones.isEmpty()) {
                    maintainSystemStateStatus("DRONES RECALLED");
                } else {
                    maintainSystemStateStatus("RECALLING DRONES");
                }
                break;
        }
    }

    @Override
    public boolean isRecallMode() {
        return droneOrders == SupportDroneOrders.RECALL;
    }

    @Override
    public void setDefaultDeployMode() {
        droneOrders = SupportDroneOrders.DEFENCE;
    }

    @Override
    public void executePerOrders(float amount) {
        switch (droneOrders) {
            case DEFENCE:

                break;
          case SHIELD:

             break;
            case RECALL:

                break;
        }
    }

    public SupportDroneOrders getDroneOrders() {
        return droneOrders;
    }

    @Override
    public dl_BaseSubsystemDroneAI getNewDroneAIInstance(dl_DroneAPI spawnedDrone) {
        return new expsp_SubsystemDroneAIMK88(spawnedDrone, this);
    }

    @Override
    public void aiInit() {

    }

    @Override
    public void aiUpdate(float amount) {

    }

    @Override
    public String getFlavourString() {
        return "LAUNCHES SUPPORT DRONES";
    }

    @Override
    public String getStatusString() {
        return null;
    }
}
