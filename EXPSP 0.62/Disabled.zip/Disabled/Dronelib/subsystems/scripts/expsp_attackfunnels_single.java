package data.subsystems.scripts;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import data.scripts.ai.dl_BaseSubsystemDroneAI;
import data.scripts.impl.dl_DroneAPI;
import data.scripts.shipsystems.example.dl_FiverDroneSystem;
import data.scripts.subsystems.dl_BaseDroneSubsystem;
import data.scripts.util.dl_SpecLoadingUtils;
import data.shipsystems.scripts.ai.expsp_SubsystemDroneAI1;

public class expsp_attackfunnels_single extends dl_BaseDroneSubsystem {
    public static final String SUBSYSTEM_ID = "expsp_drone_attackfunnel_single"; //this should match the id in the csv

    public enum AttackFunnelOrders1 {
        DEFENCE,
        SHIELD,
        RECALL
    }
    private AttackFunnelOrders1 droneOrders = AttackFunnelOrders1.RECALL;

    public expsp_attackfunnels_single() {
        super(dl_SpecLoadingUtils.droneSystemSpecHashMap.get("expsp_drone_attackfunnel_single"), dl_SpecLoadingUtils.getSubsystemData(SUBSYSTEM_ID));
    }

    @Override
    public void apply(MutableShipStatsAPI stats, String id, SubsystemState state, float effectLevel) {

    }

    @Override
    public void unapply(MutableShipStatsAPI stats, String id) {

    }

    @Override
    public void nextDroneOrder() {
        droneOrders = getNextDroneOrder();
    }

    private AttackFunnelOrders1 getNextDroneOrder() {
        if (droneOrders.ordinal() == dl_FiverDroneSystem.FiverDroneOrders.values().length - 1) {
            return AttackFunnelOrders1.values()[0];
        }
        return AttackFunnelOrders1.values()[droneOrders.ordinal() + 1];
    }

    @Override
    public void maintainStatusMessage() {
        switch (droneOrders) {
          case SHIELD:
                maintainSystemStateStatus("SHIELD ARRAY FORMATION");
               break;
            case DEFENCE:
                maintainSystemStateStatus("DEFENCE FORMATION");
                break;
            case RECALL:
                if (deployedDrones.isEmpty()) {
                    maintainSystemStateStatus("DRONES RECALLED");
                } else {
                    maintainSystemStateStatus("RECALLING DRONES");
                }
                break;
        }
    }

    @Override
    public boolean isRecallMode() {
        return droneOrders == AttackFunnelOrders1.RECALL;
    }

    @Override
    public void setDefaultDeployMode() {
        droneOrders = AttackFunnelOrders1.DEFENCE;
    }

    @Override
    public void executePerOrders(float amount) {
        switch (droneOrders) {
            case DEFENCE:

                break;
          case SHIELD:

             break;
            case RECALL:

                break;
        }
    }

    public AttackFunnelOrders1 getDroneOrders() {
        return droneOrders;
    }

    @Override
    public dl_BaseSubsystemDroneAI getNewDroneAIInstance(dl_DroneAPI spawnedDrone) {
        return new expsp_SubsystemDroneAI1(spawnedDrone, this);
    }

    @Override
    public void aiInit() {

    }

    @Override
    public void aiUpdate(float amount) {

    }

    @Override
    public String getFlavourString() {
        return "LAUNCHES 1 DEFENCE DRONE";
    }

    @Override
    public String getStatusString() {
        return null;
    }
}
