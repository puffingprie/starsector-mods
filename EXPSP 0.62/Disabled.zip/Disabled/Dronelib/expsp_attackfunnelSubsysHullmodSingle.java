package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import data.scripts.util.MagicIncompatibleHullmods;
import data.scripts.util.dl_SubsystemUtils;
import data.subsystems.scripts.expsp_attackfunnels_single;

import java.util.HashSet;
import java.util.Set;

import static data.scripts.util.expsp_stringManager.txt;

public class expsp_attackfunnelSubsysHullmodSingle extends BaseHullMod {
    private  final Set<String> BLOCKED_HULLMODS = new HashSet<>();
    {
        // These hullmods will automatically be removed
        // This prevents unexplained hullmod blocking
        BLOCKED_HULLMODS.add("expsp_attackfunnelforge");
    }
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        dl_SubsystemUtils.queueSubsystemForShip(ship, expsp_attackfunnels_single.class);
        for (String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {
                MagicIncompatibleHullmods.removeHullmodWithWarning(ship.getVariant(), tmp, "expsp_attackfunnelforge");
            }
        }
    }
    @Override
    public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
        if (index == 0) return txt("hm_warning");
        if (index == 1) return Global.getSettings().getHullModSpec("expsp_attackfunnelforge").getDisplayName();
        return null;
    }
}
